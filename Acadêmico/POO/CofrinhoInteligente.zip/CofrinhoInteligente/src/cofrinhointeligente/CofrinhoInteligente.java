/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cofrinhointeligente;

/**
 *
 * @author avrj
 */
public class CofrinhoInteligente {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Moeda m1 = new Moeda(0.5f);
        Moeda m2 = new Moeda(0.05f);
        Moeda m3 = new Moeda(1);
        Moeda m4 = new Moeda(0.25f);
        Moeda m5 = new Moeda(0.10f);
        Moeda m6 = new Moeda(0.10f);
        
        Cofrinho c = new Cofrinho();
        
        c.addMoeda(m1);
        c.addMoeda(m2);
        c.addMoeda(m3);
        c.addMoeda(m4);
        c.addMoeda(m5);
        c.addMoeda(m6);
        
        System.out.println("Verificando Cofrinho");
        System.out.printf("A - Valor total do Cofrinho: %.2f ",
                c.getValorTotal());
        System.out.println("");
        System.out.println("B - Quantidade de Moedinhas do Cofringo: "+c.getQuantMoedas());
        System.out.println("C - Maior Moeda do Cofrinho: "+c.getMoedaMaiorValor().getValor());
        System.out.println("D - Moedinhas Ordenadas: ");
        c.ordenaMoedas();
        
    }
    
}
