/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cofrinhointeligente;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author avrj
 */
public class Cofrinho {
    
    List<Moeda> lMoedas = new ArrayList();
    
    public void addMoeda(Moeda m)
    {
        lMoedas.add(m);
    }
    
    public double getValorTotal()
    {
        double total = 0;
        
        for (int i = 0; i < lMoedas.size(); i++) {
            total = total +lMoedas.get(i).getValor();
        }
        
        return total;
    }
    
    public int getQuantMoedas()
    {
        return lMoedas.size();
    }
    
    public Moeda getMoedaMaiorValor()
    {
        return Collections.max(lMoedas);
    }
    
    public void ordenaMoedas()
    {
        Collections.sort(lMoedas);
        for (int i = 0; i < lMoedas.size(); i++) {
                System.out.print(lMoedas.get(i).getValor()+" -> ");
        }
    }
}
