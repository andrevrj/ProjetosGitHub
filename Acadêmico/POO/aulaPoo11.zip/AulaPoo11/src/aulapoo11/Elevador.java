/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapoo11;

/**
 *
 * @author PICHAU
 */
public class Elevador {
    float pesoLimite;
    
    public void seMover(float peso) throws PesoException{
        //800 KG limite
        if(peso<=pesoLimite){
            System.out.println("O elevador pode se mexer");
        }else{
            throw new PesoException();
        }
    }
}
