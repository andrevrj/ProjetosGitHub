/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapoo11;

/**
 *
 * @author PICHAU
 */
public class NanicoException extends Exception{
    float altura;
    
    NanicoException(float altura){
        this.altura = altura;
    }
    
    public void explicacao(){
        System.out.println("Você não pode ir no brinquedo porque sua altura é " + altura + " e a altura mínima é 1.2m");
    }
}
