/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapoo11;

import javax.swing.JOptionPane;

/**
 *
 * @author PICHAU
 */
public class AulaPoo11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //CHECKED - EXCESSÕES TRATADAS DE FORMA OBRIGATORIA: CONEXÃO COM BD, ARQUIVO
        //UNCHECKED - NAO SÃO VERIFICADAS PREVIAMENTE OU DE FORMA OBRIGATORIA
        
        try{
            int num = 3/0;
            System.out.println("Divisão: " + num);   
        }
        catch(ArithmeticException e){
            System.out.println("Erro: " + e);
        }
        finally{
            System.out.println("Eu sempre vou rodar");
        }
        
        Pessoa[] people = new Pessoa[5];
        
        try{
            System.out.println(people[0].nome);
        }
        catch(NullPointerException e){
            System.out.println(e);     
        }
        
        try{
            System.out.println(people[8].nome);
            
            System.out.println("Estou depois da excessão ser lançada!");
        }
        catch(ArrayIndexOutOfBoundsException e){
            e.printStackTrace();
        }
        
        System.out.println("");
        System.out.println("");
        
        Pessoa p1 = new Pessoa();
        p1.nome = "Uttoni";
        p1.idade = 21;
        p1.altura = 1.19f;
        p1.irNaMontanhaRussa();
        
        System.out.println("");
        System.out.println("");
        
        Elevador e1 = new Elevador();
        e1.pesoLimite = 800;
        try{
            e1.seMover(1500);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
        JOptionPane.showMessageDialog(null, "Continuo Rodando....");
    }
}
