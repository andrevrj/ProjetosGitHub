/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapoo11;

/**
 *
 * @author PICHAU
 */
public class Pessoa {
    String nome;
    int idade;
    float altura;
    
    public void irNaMontanhaRussa(){
        try{
            //1.2m
            if(altura<1.2){
                throw new NanicoException(altura);
            }else{
                System.out.println("Você pode ir no brinquedo!");
            }
        }catch(NanicoException e){
            e.explicacao();
        }
    }
}
