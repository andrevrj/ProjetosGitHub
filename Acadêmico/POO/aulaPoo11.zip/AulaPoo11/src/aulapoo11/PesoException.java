/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapoo11;

/**
 *
 * @author PICHAU
 */
public class PesoException extends Exception{
    
    PesoException(){
        System.out.println("Peso limite foi excedido!");
    }
}
