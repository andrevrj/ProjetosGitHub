/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapoo12.br.inatel.canil.controller;

import aulapoo12.br.inatel.canil.model.Cachorro;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 *
 * @author PICHAU
 */
public class Arquivo {
    //ESCREVER
    OutputStream os = null;
    OutputStreamWriter osw = null;
    BufferedWriter bw = null;
    
    //LER
    InputStream is = null;
    InputStreamReader isr = null;
    BufferedReader br = null;
    
    
    public void escreverCachorro(Cachorro cao){
        
        
        try{
            os  = new FileOutputStream("arquivo1.txt", true);
            osw = new OutputStreamWriter(os);
            bw = new BufferedWriter(osw);
            bw.write("---------------Cachorro-----------------\n");
            bw.write(cao.nome + "\n");
            bw.write(cao.raca + "\n");
            bw.write(cao.idade + "\n");
            bw.write(cao.peso + "\n");
            
        }catch(Exception e){
            System.out.println("Erro na entrada: " + e);
        }
        finally{
            try{
                bw.close();
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
    }
    
    public Cachorro[] lerCachorro(){
        String linhaLer = null;
        Cachorro[] caes = new Cachorro[15];
        
        try{
            is  = new FileInputStream("arquivo1.txt");
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);
            
            int i = 0;
            linhaLer = br.readLine();
            while(linhaLer != null){
                if(linhaLer.contains("-Cachorro-")){
                    Cachorro aux = new Cachorro();
                    aux.nome = br.readLine();
                    aux.raca = br.readLine();
                    aux.idade = Integer.parseInt(br.readLine());
                    aux.peso = Float.parseFloat(br.readLine());
                    caes[i] = aux;
                    i++;
                }
                linhaLer = br.readLine();
            }
                     
        }catch(Exception e){
            System.out.println(e);
        }
        finally{
            try{
                br.close();
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
        
        return caes;
    }
    
}
