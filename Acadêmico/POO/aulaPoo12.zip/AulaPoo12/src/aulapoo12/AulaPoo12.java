/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulapoo12;

import aulapoo12.br.inatel.canil.controller.Arquivo;
import aulapoo12.br.inatel.canil.model.Cachorro;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 *
 * @author PICHAU
 */
public class AulaPoo12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        Cachorro c1 = new Cachorro();
        c1.nome = "Princesa";
        c1.raca = "Fox Paulista";
        c1.idade = 5;
        c1.peso = 21.7f;
        
        
        //ESCREVER NO ARQUIVO =================================================================================
        OutputStream os = null;
        OutputStreamWriter osw = null;
        BufferedWriter bw = null;
        String linhaEscrever;
        
        try{
            os  = new FileOutputStream("arquivo1.txt", true);
            osw = new OutputStreamWriter(os);
            bw = new BufferedWriter(osw);
            linhaEscrever = "minha primeira linha em arquivo";
            bw.write(linhaEscrever);
            bw.write("mais alguma coisa...\n");
            bw.write("minha segunda linha");
            bw.newLine();
            bw.write("finalmente a terceira linha");
            bw.write(c1+"\n");
            bw.write("---------------Cachorro-----------------\n");
            bw.write(c1.nome + "\n");
            bw.write(c1.raca + "\n");
            bw.write(c1.idade + "\n");
            bw.write(c1.peso + "\n");
            
        }catch(Exception e){
            System.out.println("Erro na entrada: " + e);
        }
        finally{
            try{
                bw.close();
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
        
        
        //LER O ARQUIVO===============================================================================
        InputStream is = null;
        InputStreamReader isr = null;
        BufferedReader br = null;
        String linhaLer = null;
        
        Cachorro[] caes = new Cachorro[15];
        
        try{
            is  = new FileInputStream("arquivo1.txt");
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);
            
            int i = 0;
            linhaLer = br.readLine();
            while(linhaLer != null){
                if(linhaLer.contains("-Cachorro-")){
                    Cachorro aux = new Cachorro();
                    aux.nome = br.readLine();
                    aux.raca = br.readLine();
                    aux.idade = Integer.parseInt(br.readLine());
                    aux.peso = Float.parseFloat(br.readLine());
                    caes[i] = aux;
                    i++;
                }
                linhaLer = br.readLine();
            }
                     
        }catch(Exception e){
            System.out.println(e);
        }
        finally{
            try{
                br.close();
            }
            catch(Exception e){
                System.out.println(e);
            }
        }
        
        
        for(int i=0; i<caes.length; i++){
            if(caes[i] != null){
                System.out.println("Nome: " + caes[i].nome);
                System.out.println("Raça: " + caes[i].raca);
                System.out.println("Idade: " + caes[i].idade);
                System.out.println("Peso: " + caes[i].peso);
            }
        }*/

        //COM UMA CLASSE ARQUIVO
        Cachorro c2 = new Cachorro();
        c2.nome = "Luna";
        c2.raca = "Fox Paulista";
        c2.idade = 3;
        c2.peso = 15.6f;
        
        Arquivo a = new Arquivo();
        a.escreverCachorro(c2);
        Cachorro[] caezinhos = a.lerCachorro();
        
        for(int i=0; i<caezinhos.length; i++){
            if(caezinhos[i] != null){
                System.out.println("Nome: " + caezinhos[i].nome);
                System.out.println("Raça: " + caezinhos[i].raca);
                System.out.println("Idade: " + caezinhos[i].idade);
                System.out.println("Peso: " + caezinhos[i].peso);
            }
        }

        aulapoo12.br.inatel.canil.outroModel.Cachorro outroCao = 
                new aulapoo12.br.inatel.canil.outroModel.Cachorro();
        outroCao.codigo = 12355;
        
    }
    
}
