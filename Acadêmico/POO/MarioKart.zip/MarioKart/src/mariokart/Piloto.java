package mariokart;


public class Piloto {
    
    String nome;
    boolean vilao;
    
      void soltaSuperPoder(String piloto){
    
       System.out.println("O piloto "+piloto+"destruiu o adversário!");
    
   }
    
}
