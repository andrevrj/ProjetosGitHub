
package mariokart;


public class Kart {
   
    String nome;
    Piloto plt;
    Motor mot = new Motor();
   
    void jump(String kart, String piloto ){
        System.out.println("O "+kart+" do piloto "+piloto+
            " pulou!");
              
    }
    
    void Turbo( String piloto, float veloMax ){
        System.out.println("O "+piloto+" soltou um turbo e atingiu a "
                +veloMax+" km/h");
        
    }
    
    void fazerDrift( String kart){
         System.out.println("O "+kart+" fez um drift!");
            }
    
}