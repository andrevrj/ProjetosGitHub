
package mariokart;


public class MarioKart {

    
    public static void main(String[] args) {
        Piloto piloto0 = new Piloto();
        piloto0.nome = "Bowser";
        piloto0.vilao = true;
        
        Piloto piloto1 = new Piloto();
        piloto1.nome = "Luigi";
        piloto1.vilao = false;
        
        Kart kart0 = new Kart();
        kart0.nome = "Standard";
        
        Kart kart1 = new Kart();
        kart1.nome = "Sprinter";
        
        kart0.plt = piloto0;
        kart1.plt = piloto1;
        
       
        kart0.mot.cilindradas = "125cc";
        kart0.mot.velocidadeMaxima = 110f;
       
        kart1.mot.cilindradas = "150cc";
        kart1.mot.velocidadeMaxima = 130f;
        
             
        System.out.println("O "+kart0.nome+" do "+kart0.plt.nome+" tem "+kart0.mot.cilindradas+
                    " e atinge até "+kart0.mot.velocidadeMaxima+" km/h!");
        System.out.println("O "+kart1.nome+" do "+kart1.plt.nome+" tem "+kart1.mot.cilindradas+
                    " e atinge até "+kart1.mot.velocidadeMaxima+" km/h!");
   
        System.out.println("");
        
        if ( kart0.plt.vilao == true ) {
            
            System.out.println("O "+kart0.plt.nome+" é o vilão da corrida!");
            
        } else {
            
            System.out.println("O "+kart0.plt.nome+" não é o vilão da corrida!");
            
        }
        
        if ( kart1.plt.vilao == true ) {
            
            System.out.println("O "+kart1.plt.nome+" é o vilão da corrida!");
            
        } else {
            
            System.out.println("O "+kart1.plt.nome+" não é o vilão da corrida!");
            
        }
        
        System.out.println("");
        
  
        kart0.plt.soltaSuperPoder( kart0.plt.nome );
        kart1.plt.soltaSuperPoder( kart1.plt.nome );
        
        System.out.println("");
        
      
        kart0.fazerDrift( kart0.nome);
        kart1.fazerDrift( kart1.nome );
        
        System.out.println("");
        
        kart0.jump( kart0.nome, kart0.plt.nome );
        kart1.jump( kart1.nome, kart1.plt.nome );
        
        System.out.println("");
        
        kart0.Turbo( kart0.plt.nome, kart0.mot.velocidadeMaxima);
        kart1.Turbo( kart1.plt.nome, kart1.mot.velocidadeMaxima);
        
        
    }
    
}
