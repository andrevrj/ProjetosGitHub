/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author andrevrj
 */
public class ProcessoOnibus implements Runnable {
    
    FilaOnibus fila;
    
    public ProcessoOnibus(FilaOnibus f){
        fila = f;
    }
    
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()
                +" pronto para partir.");
        //fila.seguirSemSemaforo();
        fila.avancarComSemaforo();
    }
}
