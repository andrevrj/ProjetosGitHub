
import java.util.concurrent.Semaphore;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author andrevrj
 */
public class FilaOnibus {
    
    public void seguirSemSemaforo(){
        System.out.println(Thread.currentThread().getName()
                + " em rota");
        System.out.println("Onibus "
                + Thread.currentThread().getName()
                + " chegou!");
    }
    
    Semaphore semaforo = new Semaphore(1);
    
    public void avancarComSemaforo(){
        try {
            semaforo.acquire();
            System.out.println(Thread.currentThread().getName()
                    + " em rota!");
        } catch (InterruptedException ex) {}
        finally {
            System.out.println("Onibus da "
                    + Thread.currentThread().getName()
                    + " chegou com sucesso!");
            semaforo.release();
        }
    }  
}
