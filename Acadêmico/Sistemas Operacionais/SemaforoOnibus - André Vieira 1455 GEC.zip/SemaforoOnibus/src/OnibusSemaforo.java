/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author andrevrj
 */
public class OnibusSemaforo {
    
    public static void main(String[] args){
        FilaOnibus fila = new FilaOnibus();
        
        Thread[] thread = new Thread[3];
        for (int i = 0; i < 3; i++) {
            thread[i] = new Thread(
                    new ProcessoOnibus(fila));
        }
        
        for (int i = 0; i < 3; i++) {
            thread[i].start();
        }
    }
    
}
