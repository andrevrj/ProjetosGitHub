export const environment = {
  production: true,
  server: {
    protocol: 'http',
    host: 'localhost',
    port: '8081',
  },
};
