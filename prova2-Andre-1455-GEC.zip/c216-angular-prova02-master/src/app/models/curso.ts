export class Curso {
  id?: number;
  descricao?: string;
  cargaHoraria?: number;
}
